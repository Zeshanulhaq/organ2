<?php
// Include database connection or use your connection logic
include 'admin.php';

// Function to fetch counts
function fetchCounts($conn) {
    $counts = array();

    // Query to count patients
    $patientQuery = "SELECT COUNT(*) AS patientCount FROM patient";
    $patientResult = mysqli_query($conn, $patientQuery);
    $patientCount = mysqli_fetch_assoc($patientResult)['patientCount'];
    $counts['patients'] = $patientCount;

    // Query to count donors
    $donorQuery = "SELECT COUNT(*) AS donorCount FROM donor";
    $donorResult = mysqli_query($conn, $donorQuery);
    $donorCount = mysqli_fetch_assoc($donorResult)['donorCount'];
    $counts['donors'] = $donorCount;

    // Query to count healthcare professionals
    $hcpQuery = "SELECT COUNT(*) AS hcpCount FROM healthcare_professional";
    $hcpResult = mysqli_query($conn, $hcpQuery);
    $hcpCount = mysqli_fetch_assoc($hcpResult)['hcpCount'];
    $counts['healthcareProfessionals'] = $hcpCount;

    return $counts;
}

// Call the function to fetch counts
$counts = fetchCounts($conn);

// Return counts as JSON response
header('Content-Type: application/json');
echo json_encode($counts);
?>
